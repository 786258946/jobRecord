<?php


namespace app\index\controller;


use app\common\controller\Frontend;

class Login extends Frontend
{
    /**
     * methods POST
     *
     */
    public function Login()
    {
        $params=$this->request->post('');

        //验证器
        $validate = Loader::validate('Login');
        if (!$validate->check($params)) {
            $this->error($validate->getError());
        }
        $table = $params['type']?'staff':'manager'; //为1，员工登录 否则管理员登录

        unset($params['type']);
        $params['state'] = 1;

        $row = Db::table($table)
            ->where($params)
            ->find();
        if (!$row) $this->error('该账户名或密码错误!');

        $this->success('登录成功!','', ['data'=>$row]);
    }
}