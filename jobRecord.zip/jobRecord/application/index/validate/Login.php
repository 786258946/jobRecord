<?php

namespace app\index\validate;

use think\Validate;

class User extends Validate
{
    /**
     * 验证规则
     */
    protected $rule = [
        'username' => 'require',
        'passwd' => 'require',
        'type' => 'require',
    ];

    /**
     * 字段描述
     */
    protected $field = [
    ];
    /**
     * 提示消息
     */
    protected $message = [
        'username.require' =>'用户名不能为空',
        'passwd.require' =>'密码不能为空',
        'type.require' =>'请选择登录类型',
    ];


}
