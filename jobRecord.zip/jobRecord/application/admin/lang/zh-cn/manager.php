<?php

return [
    'Username'   => '账号',
    'Passwd'     => '密码',
    'Name'       => '姓名',
    'Head_img'   => '头像',
    'State'      => '状态',
    'Createtime' => '注册时间'
];
