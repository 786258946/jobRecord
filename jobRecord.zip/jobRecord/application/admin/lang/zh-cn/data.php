<?php

return [
    'Name'         => '客户名称',
    'Work_type'    => '作业类型',
    'Work_address' => '作业地点',
    'Work_area'    => '作业面积',
    'Pay_money'    => '收费金额',
    'Pay_way'      => '收费方式',
    'Mobile'       => '电话',
    'Remark'       => '备注',
    'Drug_typenum' => '用药量以及类型',
    'Img_url'      => '图片',
    'Createtime'   => '创建时间'
];
