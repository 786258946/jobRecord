define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'data/index' + location.search,
                    add_url: 'data/add',
                    edit_url: 'data/edit',
                    del_url: 'data/del',
                    multi_url: 'data/multi',
                    import_url: 'data/import',
                    table: 'data',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'name', title: __('Name'), operate: 'LIKE'},
                        {field: 'work_type', title: __('Work_type'), operate: 'LIKE'},
                        {field: 'work_address', title: __('Work_address'), operate: 'LIKE'},
                        {field: 'work_area', title: __('Work_area'), operate: 'LIKE'},
                        {field: 'pay_money', title: __('Pay_money'), operate: 'LIKE'},
                        {field: 'pay_way', title: __('Pay_way'), operate: 'LIKE'},
                        {field: 'mobile', title: __('Mobile'), operate: 'LIKE'},
                        {field: 'drug_typeNum', title: __('Drug_typenum'), operate: 'LIKE'},
                        {field: 'img_url', title: __('Img_url'), operate: 'false', formatter: Table.api.formatter.image},
                        {field: 'staff.name', title: __('员工'), operate: 'LIKE'},
                        {field: 'createtime', title: __('Createtime'), formatter: Table.api.formatter.datetime, operate: 'RANGE', addclass:'datetimerange'},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});